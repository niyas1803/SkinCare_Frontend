document.addEventListener('DOMContentLoaded', function () {
  const search = document.getElementById('siteSearch');
  const brandBoxes = document.querySelectorAll('.brand-filter');
  const productCards = document.querySelectorAll('.product-card');
  const countElement = document.querySelector('.listing-top .count') || document.getElementById('productCount');
  const urlParams = new URLSearchParams(window.location.search);
  const urlBrand = (urlParams.get('brand') || '').trim();
  const urlBrandLower = urlBrand.toLowerCase();

  function applyFilters() {
    const term = search ? search.value.toLowerCase().trim() : '';
    const selected = document.querySelector('.brand-filter:checked');
    const selectedBrand = selected ? selected.value.trim().toLowerCase() : urlBrandLower;
    let visibleCount = 0;

    productCards.forEach(function(card) {
      const cardBrand = (card.getAttribute('data-brand') || '').trim().toLowerCase();
      const text = card.innerText.toLowerCase();
      const matchesBrand = !selectedBrand || cardBrand === selectedBrand;
      const matchesSearch = !term || text.includes(term);
      const show = matchesBrand && matchesSearch;
      card.hidden = !show;
      if (show) visibleCount++;
    });

    if (countElement) {
      countElement.textContent = visibleCount + (visibleCount === 1 ? ' Product' : ' Products');
    }
  }

  brandBoxes.forEach(function(box) {
    box.addEventListener('change', function() {
      if (this.checked) {
        brandBoxes.forEach(function(other) {
          if (other !== box) other.checked = false;
        });
      }
      applyFilters();
    });
  });

  if (search) search.addEventListener('input', applyFilters);

  // Category checkboxes: no category is selected on a fresh page.
  // When a category is clicked, it stays visibly selected.
  const categoryBoxes = document.querySelectorAll('.category-filter');
  const currentPage = window.location.pathname.split('/').pop() || 'serum.html';
  const params = new URLSearchParams(window.location.search);
  const selectedCategory = params.get('selected');

  if (selectedCategory) {
    categoryBoxes.forEach(function(box) {
      box.checked = box.value.toLowerCase() === selectedCategory.toLowerCase();
    });
  }

  categoryBoxes.forEach(function(box) {
    box.addEventListener('change', function() {
      if (!this.checked) return;
      categoryBoxes.forEach(function(other) {
        if (other !== box) other.checked = false;
      });
      const target = this.dataset.page;
      if (target === currentPage) {
        window.history.replaceState({}, '', currentPage + '?selected=' + encodeURIComponent(this.value));
        return;
      }
      window.location.href = target + '?selected=' + encodeURIComponent(this.value);
    });
  });

  // Brand links from Home/Brands pages use ?brand=... . Apply that brand immediately.
  if (urlBrand) {
    brandBoxes.forEach(function(box) {
      box.checked = box.value.trim().toLowerCase() === urlBrandLower;
    });
    const title = document.getElementById('listingTitle');
    if (title) title.textContent = urlBrand + ' Products';
  }

  document.querySelectorAll('.sort-select').forEach(function(select) {
    select.addEventListener('change', function() {
      const grid = this.closest('.listing').querySelector('.product-grid');
      if (!grid) return;
      const cards = Array.from(grid.querySelectorAll('.product-card'));
      cards.sort(function(a,b) {
        if (select.value === 'rating') return Number(b.dataset.rating) - Number(a.dataset.rating);
        if (select.value === 'price-low') return Number(a.dataset.price) - Number(b.dataset.price);
        if (select.value === 'price-high') return Number(b.dataset.price) - Number(a.dataset.price);
        return 0;
      });
      cards.forEach(function(card) { grid.appendChild(card); });
      applyFilters();
    });
  });

  applyFilters();
});
